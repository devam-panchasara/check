# @ruttl/mobile-sdk

React Native SDK for in-app bug reporting. Host apps embed a draggable FAB that captures a screenshot, lets users annotate it, fill in ticket details, and submit to the Ruttl API. Supports **Android and iOS** with identical code paths.

> **AI / agent context:** [mobile-sdk-development/SKILL.md](../../skills/mobile-sdk-development/SKILL.md) · [AGENTS.md](./AGENTS.md) · [@agents](../../AGENTS.md)

## Features

### Bug reporting flow
- **Draggable FAB**: Floating action button snaps to screen edges; respects safe-area insets
- **Screenshot capture**: Full-screen capture via `react-native-view-shot`; image-picker fallback when capture fails
- **SVG annotation**: Draw on the screenshot with three colors, undo, and edge guards to prevent accidental strokes
- **Feedback form**: Title (required), description, priority, due date, and assignee multi-select
- **Annotated export**: Hidden off-screen view composites image + SVG paths for submission

### API & reliability
- **Ruttl API integration**: Project details and ticket submission via `@ruttl/constants` endpoints
- **Auth**: Plugin token sent as `x-plugin-code` header
- **Retries**: Up to 3 attempts with 1s / 2s / 4s backoff on network errors and 5xx responses
- **Offline queue**: Failed submissions persisted in AsyncStorage and flushed when connectivity returns
- **Screen tracking**: Mandatory — Expo Router (automatic) or `BugTrackingInstrumentation` (React Navigation)

### Platform
- **Android + iOS**: No platform early-return; both paths are first-class
- **Gesture Handler v2**: `Gesture.Pan()` + `GestureDetector` (Reanimated shared values for FAB)
- **Expo-compatible**: Uses `expo-constants` for build metadata when available

## Local testing (before publish)

Install into any external React Native app via a local tarball (same artifact as npm):

```bash
pnpm --filter @ruttl/mobile-sdk install:host /absolute/path/to/YourHostApp
```

Then `npx pod-install` (iOS) and run the host app. Full workflow — iteration loop, `RUTTL_APP_ORIGIN`, peer deps, QA checklist, troubleshooting — is in **[docs/local-testing.md](./docs/local-testing.md)**.

## Installation

Install the SDK and its peer dependencies in your React Native host app:

```bash
npm install @ruttl/mobile-sdk
```

Peer dependencies (install in the host app):

```
react, react-native, react-native-view-shot, react-native-gesture-handler,
react-native-svg, react-native-reanimated, react-native-device-info,
react-native-image-picker, react-native-calendars, toastify-react-native,
expo-constants, expo-file-system, @react-native-async-storage/async-storage,
react-native-safe-area-context, @react-native-community/netinfo
```

### iOS setup

Add to `Info.plist`:

```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>Upload a screenshot when screen capture is unavailable</string>
```

Ensure `GestureHandlerRootView` wraps your app (provided automatically by `wrapWithBugTracking`).

### Screen instrumentation (required)

Every integration must provide a **screen name** on bug tickets (`screenName`). Choose one:

| Host app | Setup |
| -------- | ----- |
| **Expo Router** | None — `BugTrackingRoot` auto-syncs from `usePathname()` |
| **React Navigation** | `BugTrackingInstrumentation` + `registerNavigationContainer(ref)` |
| **Custom router** | `useBugTrackingScreen(name)` (advanced) |

In `__DEV__`, the SDK throws if no screen source is active ~2.5s after mount.

### Migrating from 1.x

1. Remove `@ruttl/mobile-sdk/babel-plugin-ruttl-targets` from `babel.config.js`.
2. Keep screen instrumentation (table above).
3. Bug tickets no longer include `target` metadata — `screenName` is used by MCP instead.

## Usage

Both integration paths use the same primitives: `GestureHandlerRootView`, the bug-reporting widget, and automatic screen tracking when Expo Router is installed.

### Option A — `AppRegistry` (bare React Native)

```tsx
import {
  wrapWithBugTracking,
  BugTrackingInstrumentation,
} from "@ruttl/mobile-sdk";

const instrumentation = new BugTrackingInstrumentation();

AppRegistry.registerComponent("MyApp", () =>
  wrapWithBugTracking(App, {
    projectID: "your-project-id",
    token: "your-plugin-token",
    instrumentation,
  }),
);

// React Navigation — attach screen name to tickets
instrumentation.registerNavigationContainer(navigationRef);
```

### Option B — layouts (Expo Router and custom roots)

Same ergonomics as Option A: one wrapper, no manual pathname wiring.

```tsx
// app/_layout.tsx
import { Stack } from "expo-router";
import { BugTrackingRoot } from "@ruttl/mobile-sdk";

export default function RootLayout() {
  return (
    <BugTrackingRoot projectID="your-project-id" token="your-plugin-token">
      <Stack />
    </BugTrackingRoot>
  );
}
```

`BugTrackingRoot` provides `GestureHandlerRootView`, mounts the widget, and **auto-detects Expo Router** for `screenName` on tickets. No `usePathname`, overlay component, or extra hooks required.

### React Navigation without Expo Router

`BugTrackingInstrumentation` is **required** — pass it to `BugTrackingRoot` and wire the navigation ref:

```tsx
const instrumentation = new BugTrackingInstrumentation();

export default function RootLayout() {
  return (
    <BugTrackingRoot instrumentation={instrumentation} projectID="..." token="...">
      <NavigationContainer ref={(ref) => instrumentation.registerNavigationContainer(ref)}>
        {/* screens */}
      </NavigationContainer>
    </BugTrackingRoot>
  );
}
```

### Advanced

- `useBugTrackingScreen(name)` — custom routers (counts as screen instrumentation when name is set)
- `Widget` — only when you manage the full root yourself; you must still satisfy screen instrumentation guards

## Architecture

### Key components

```
packages/mobile-sdk/
├── src/
│   ├── index.ts                    # Public exports
│   ├── widget.tsx                  # Thin orchestrator — wires hooks + UI
│   ├── wrap-with-bug-tracking.tsx  # HOC wrapper with GestureHandlerRootView
│   ├── instrumentation.ts          # Screen name tracker for React Navigation
│   ├── api.ts                      # HTTP client, retry queue, coord helpers
│   ├── lib/
│   │   ├── constants.ts            # UI dimensions, colors, priority map
│   │   ├── device.ts               # Build number and timing helpers
│   │   └── widget-styles.ts        # Shared StyleSheet definitions
│   ├── hooks/
│   │   ├── use-bug-widget.ts       # Widget state, reset, assignee filter
│   │   ├── use-capture.ts          # Screenshot capture + picker fallback
│   │   ├── use-drawing.ts          # SVG path gestures and edge guards
│   │   ├── use-fab-gesture.ts      # Draggable FAB pan/tap
│   │   └── use-submit.ts           # Payload build and API submit
│   └── components/
│       ├── fab.tsx                 # Floating action button
│       ├── annotation-canvas.tsx   # Screenshot + SVG overlay
│       ├── upload-fallback.tsx     # Manual image upload UI
│       ├── feedback-sheet.tsx      # Description, priority, date, assignees
│       └── preview-modal.tsx       # Full-screen annotation + submit UI
├── types/index.d.ts                # Published TypeScript declarations
├── tsup.config.ts                  # CJS + ESM bundle config
└── tsconfig.json                   # `@/*` → `./src/*` path alias
```

### User flow

1. User taps FAB → screenshot → annotation modal
2. User draws annotations and enters title; optional fields in bottom sheet
3. Submit → `captureRef` export + POST `/api/mobile` with `screenName`, `annotationPaths`, `highlightedCoords`
4. Success toast + reset; failure queued for offline retry

### Backend routes

Mobile ticket API lives in the Ruttl web app:

| Route | Method | Purpose |
|---|---|---|
| `/api/mobile/project-details` | POST | Fetch project assignees |
| `/api/mobile` | POST | Create mobile bug ticket |

Auth: `verifyTokenOrPluginCode()` — `x-plugin-code` header.

## API client behaviour

Configured in `src/api.ts`:

| Setting | Value |
|---|---|
| Request timeout | 10s per attempt |
| Max retries | 3 (backoff 1s / 2s / 4s) |
| Retry queue key | `@ruttl/mobile-sdk/retry-queue` |
| Auth header | `HttpHeaders.PluginCode` from `@ruttl/constants` |

### Submit payload

`comment`, `description`, `height` (annotation canvas = `CH`), `width` (`SW`), `osName`, `appId`, `buildNumber`, `highlightedCoords`, `image` (data URI), `projectID`, `screenName`, `annotationPaths` (SVG strokes), optional `priority` (1/2/3), `dueDate` (ISO), `assignedTo` (uid[]), `appVersion`, `device`.

`height` / `width` must match the exported JPEG dimensions (65% screen height canvas), not full device height — required for correct highlight cropping in the web app.

## Development

From the monorepo root:

```bash
# Install dependencies
pnpm install --filter @ruttl/mobile-sdk...

# Format, lint, typecheck, build
pnpm --filter @ruttl/mobile-sdk format
pnpm --filter @ruttl/mobile-sdk lint
pnpm --filter @ruttl/mobile-sdk check-types
pnpm --filter @ruttl/mobile-sdk build

# Watch mode
pnpm --filter @ruttl/mobile-sdk dev

# Pack tarball or install into a host app (see docs/local-testing.md)
pnpm --filter @ruttl/mobile-sdk pack:local
pnpm --filter @ruttl/mobile-sdk install:host /path/to/YourHostApp
```

### Build output

- **Entry**: `src/index.ts`
- **Formats**: CJS (`dist/index.js`) + ESM (`dist/index.mjs`) + declarations
- **`@ruttl/constants`**: Bundled into published output (`noExternal`)
- **React Native libs**: External — must resolve from host `node_modules`

## Publish

```bash
pnpm --filter @ruttl/mobile-sdk build
cd packages/mobile-sdk && npm publish --access public
```

Test in a host app first — see [docs/local-testing.md](./docs/local-testing.md) (`install:host` script).

`prepublishOnly` runs `scripts/prepublish.mjs`: builds, rejects `workspace:` in `dependencies`, verifies `@ruttl/constants` is bundled and RN libs stay external.

Before publishing, verify `dist/` references RN libs as `require("react-native-…")`, not inlined bundles.

## Error handling

- **Capture failure**: Falls back to image picker upload UI
- **Submit failure**: Payload queued in AsyncStorage; toast shown to user
- **Retry flush**: Skipped when `NetInfo.fetch().isConnected === false`; failed items stay in queue (no duplicate re-queue on flush failure)
- **Missing config**: `Widget` logs a warning and renders `null` when `projectID` or `token` is absent

## Out of scope

The SDK intentionally does **not** include:

- Screen recording (`expo-video`, `expo-audio`, `react-native-compressor`)
- Custom native modules or an `android/` directory
- Cloud upload flows outside the Ruttl API

## Monitoring

- **Toasts**: Success / failure feedback via `toastify-react-native`
- **Console**: Warning when required props are missing
- **Offline queue**: Inspect AsyncStorage key `@ruttl/mobile-sdk/retry-queue` during QA
